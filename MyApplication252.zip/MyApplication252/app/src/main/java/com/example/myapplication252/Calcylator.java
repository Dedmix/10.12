package com.example.myapplication252;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Calcylator extends AppCompatActivity {

    TextView txt;
    int buffer;
    char op;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcylator);
        op='1'; buffer =0;
        txt = findViewById(R.id.tet);
        Button ans = findViewById(R.id.equal);
        ans.setOnClickListener(view -> {
            switch (op){
                case '+':
                    buffer +=Integer.parseInt(txt.getText().toString());
                    txt.setText(String.valueOf(buffer));
                    break;
                case '-':
                    buffer -=Integer.parseInt(txt.getText().toString());
                    txt.setText(String.valueOf(buffer));
                    break;
                case '*':
                    buffer *=Integer.parseInt(txt.getText().toString());
                    txt.setText(String.valueOf(buffer));
                    break;
                case '/':
                    buffer /=Integer.parseInt(txt.getText().toString());
                    txt.setText(String.valueOf(buffer));
                    break;

            }
        });
    }
    public  void  ops(View view){
        buffer = Integer.parseInt(txt.getText().toString());
        Button b = (Button) view;
        op=b.getText().charAt(0);
        txt.setText("");
        Log.d("ops",buffer+" "+op);
    }
    public void appendText (View view){
        Button b = (Button) view;
        txt.setText(txt.getText().toString()+b.getText().toString());




         //}
  //  public void onButtonClick (View v){
     //   EditText el1 = (EditText)findViewById(R.id.Num1);
     //     EditText el2 = (EditText)findViewById(R.id.Num2);
     //    TextView resText = (TextView)findViewById(R.id.Result);
     //   TextView minText = (TextView)findViewById(R.id.Result);
     //   TextView ymnText = (TextView)findViewById(R.id.Result);
     //   TextView gelText = (TextView)findViewById(R.id.Result);
     //   TextView kvaText = (TextView)findViewById(R.id.Result);


       // int num1 = Integer.parseInt(el1.getText().toString());
       // int num2 = Integer.parseInt(el2.getText().toString());
       // int Mmin = num1-num2;
       // int SSum = num1+num2;
       // int Yymn = num1*num2;
       // int Ggel = num1/num2;
       // int Kkva = num1*num1;

       // resText.setText(Integer.toString(SSum));
       // resText.setText(Integer.toString(Mmin));
       // resText.setText(Integer.toString(Yymn));
       // resText.setText(Integer.toString(Ggel));
       // resText.setText(Integer.toString(Kkva));




    }
}
package com.example.myapplication252;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button Algebra = (Button) findViewById(R.id.Algebra);
        Algebra.setOnClickListener((View.OnClickListener) this);
    }
    public void onClick(View view) {
        Intent a;
        a=new Intent(this, Algebra.class);
        startActivity(a);
    }
    public void onClick4(View view) {
        Intent c;
        c=new Intent(this, Calcylator.class);
        startActivity(c);
    }
    public void  onClick2(View view){
        Intent g;
        g=new Intent(this, Geometry.class);
        startActivity(g);
    }
    public void onClick3(View view){
        Intent p;
        p=new Intent(this, Physics.class);
        startActivity(p);
    }

}